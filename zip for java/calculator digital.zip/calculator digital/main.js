function calculate(x){
    
form.display.value = form.display.value + x;

}